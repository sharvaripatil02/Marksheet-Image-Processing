package com.image.servlets;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.image.processing.ImageProcessing;

/**
 * Servlet implementation class ImageProcessServlet
 */
@SuppressWarnings("serial")
@WebServlet("/ImageProcessServlet")
@MultipartConfig(maxFileSize = 16177215)  
public class ImageProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImageProcessServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 // PrintWriter printWriter=response.getWriter();
	        InputStream inputStream = null; // input stream of the upload file
	         String image_name=null;
	        // obtains the upload file part in this multipart request
	        Part filePart = request.getPart("pic");
	        System.out.println(filePart);
	        if (filePart != null) {
	            // prints out some information for debugging
	            System.out.println(filePart.getName());
	            System.out.println(filePart.getSize());
	            System.out.println(filePart.getContentType());
	             
	            // obtains input stream of the upload file
	            inputStream = filePart.getInputStream();
	           image_name=filePart.getName();
	          
	        }
	        BufferedImage srcImage = ImageIO.read(inputStream);
			System.out.println(srcImage);
			
			// creating object for calling toGrey() method and binarize()
			ImageProcessing ob=new ImageProcessing();
			
			//Reducing the size of image for reliability
			BufferedImage reducedImage=ob.scale(srcImage, 600, 600);
			//System.out.println(reducedImage);
			
			//  Convert source image into grey scale image
			
			BufferedImage greyImage=ob.toGray(reducedImage);
			System.out.println(greyImage);
			
			// Process this grey scale using otsu algorithm
			
			BufferedImage binarizrImage=ob.binarize(greyImage);
			
			response.setContentType("image/png");
			OutputStream sos=response.getOutputStream();
			//BufferedImage myImage=stuff.getImage(request.)
			ImageIO.write(binarizrImage, "png", sos);
			 // response.getOutputStream().flush();  
			sos.flush();
	}

}
