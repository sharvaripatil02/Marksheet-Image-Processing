package com.image.connection;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;
public class DBManager {
	public static Connection conn;
	static {
		try {
			String dbURL = "jdbc:mysql://localhost:3307/visual_cryptography";
			String username = "root";
			String password = "root";
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(dbURL, username, password);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean imageUpload(String image_name, InputStream inputStream) {
		String sql = "insert into image (image_name,image_data)values(?, ?)";
		boolean row = false;
		try {
			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, image_name);
			if (inputStream != null) {
				// fetches input stream of the upload file for the blob column
				statement.setBlob(2, inputStream);
				if (statement.executeUpdate() > 0)
					row = true;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}
	public ResultSet getImage(String sql)
	{
		Statement statement=null;
		ResultSet resultSet=null;
		try {
			statement = (Statement) conn.createStatement();
			resultSet=statement.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return resultSet;
	}


}
